console.log("Hello from the background script!");
